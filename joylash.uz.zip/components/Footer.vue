<template>
    <div id="footer">
        <div class="title">
            <p>Discover the Comfort of Your Life</p>
        </div>
        <div class="mainBox">
            <ul class="logo">
                <p>Joylash</p>
            </ul>
            <ul class="categories">
                <li>
                    <NuxtLink to="/">
                        Home
                    </NuxtLink>
                </li>
                <li>Categories</li>
                <li>Packages</li>
                <li>Blog</li>
                <li>Contact</li>
                <li>Licensing</li>
            </ul>
            <div class="line"></div>
            <ul class="categories two">
                <li>House</li>
                <li>Apartment</li>
                <li>Office</li>
                <li>Warehouse</li>
            </ul>
        </div>
        <div class="social">
            <div class="circle">
                <NuxtLink to="">
                    <img src="~/public/icons/X.svg" alt="">
                </NuxtLink>
            </div>
            <div class="circle">
                <img src="~/public/icons/facebook.svg" alt="">
            </div>
            <div class="circle">
                <img src="~/public/icons/instagram.svg" alt="">
            </div>
            <div class="circle">
                <img src="~/public/icons/linkedin.svg" alt="">
            </div>
        </div>
    </div>
</template>

<script>
export default {

}
</script>

<style></style>