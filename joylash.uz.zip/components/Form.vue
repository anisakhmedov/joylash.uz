<template>
  <div id="formFeedback">
    <div class="left">
        <p>Join Us</p>
        <h2>Get Property Insights and <br> Listings Directly to Your Email</h2>
        <span>Subscribe us to get newsleter about property information.</span>
    </div>
    <div class="right">
        <form action="post">
            <input type="text" placeholder="Insert your email here" name="feedback" id="">
            <button class="btn">Subscribe</button>
        </form>
    </div>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>