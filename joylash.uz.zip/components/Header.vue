<template>
    <header id="header">
        <div class="left">Joylash</div>
        <div class="mid">
            <ul>
                <li>Home</li>
                <li>Categories</li>
                <li>Catalogue</li>
                <li>Wishlist</li>
            </ul>
        </div>
        <div class="right">
            <div class="nav-images language">
                <img src="~/public/icons/languages.svg" alt="">
                <div class="block-lang">
                    <div class="rus">RU</div>
                    <div class="uz">UZ</div>
                    <div class="eng">ENG</div>
                </div>
            </div>
            <div class="nav-images profile">
                <NuxtLink to="">
                    <img src="~/public/icons/profile.svg" alt="">
                </NuxtLink>
            </div>
        </div>
    </header>
</template>

<script>
export default {

}
</script>

<style></style>