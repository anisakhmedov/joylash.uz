<template>
    <div id="profile">
        <div class="_margin"></div>
        <div class="info">
            <div class="colorGrd"></div>
            <div class="main">
                <div class="infoMain">
                    <div class="photo">
                        <img src="~/public/images/face.webp" alt="">
                    </div>
                    <div class="infoUser">
                        <div class="name">Alex Adams</div>
                        <div class="mail">alexadams@mail.com</div>
                    </div>
                </div>
                <form action="" >
                    <div class="inputs">
                        <div class="inp">
                            <label>Full Name</label>
                            <input type="text" placeholder="Your First Name">
                        </div>
                        <div class="inp">
                            <label>Nickname</label>
                            <input type="text" placeholder="Your Nuckname">
                        </div>
                        <div class="inp">
                            <label>Email</label>
                            <input type="text" placeholder="Your Email">
                        </div>
                        <div class="inp">
                            <label>Phone Number</label>
                            <input type="text" placeholder="Your Phone Number">
                        </div>
                        <div class="inp">
                            <label>Password</label>
                            <input type="text" placeholder="**********">
                        </div>
                        <div class="inp">
                            <label>Reset Your Password</label>
                            <input type="text" placeholder="New Password">
                        </div>
                    </div>
                    <button>Submit New Information</button>
                </form>
            </div>
        </div>
    </div>
</template>

<script>
export default {

}
</script>

<style></style>