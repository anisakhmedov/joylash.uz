<template>
    <div>
        <h1>Карта с одним домом</h1>
        
    </div>
</template>

<script setup>
import Map from '~/components/Map.vue'
</script>